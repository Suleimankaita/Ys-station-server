
const list=['http://localhost:4000','exp://172.20.10.8:8081','http://localhost:8081','http://192.168.0.102:5000','https://vtpass.com/account']

module.exports=list